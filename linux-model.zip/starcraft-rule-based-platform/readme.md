**Starcraft AI Platform 1.0**

create by sjm

tel&weixin:15173115272

email:sujiongming07@nudt.edu.cn

time:201812

Features:
-support bot vs bot

-built in AI, attack closest, and attack weakest

-openAI Gym API