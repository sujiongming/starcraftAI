# these strategies can be used by our or enemy agents
# developed by sjm
# 2019-01-10

import random
import math
import numpy as np


class AttackRandomEnemy(object):

    def act(self, obs, our_play_id, enemy_play_id):
        our_agents = obs.units[our_play_id]
        actions = []
        for i in range(len(our_agents)):
            action = self.act_one_action(i, obs, our_play_id, enemy_play_id)
            actions.append(action)
        return actions

    def act_one_action(self, i, obs, our_play_id, enemy_play_id):
        agent = obs.units[our_play_id][i]
        enemy_agents = obs.units[enemy_play_id]
        myagent_id = agent.id
        rd = random.randint(0, len(enemy_agents) - 1)
        atk_enemy_id = enemy_agents[rd].id
        return [myagent_id, atk_enemy_id]


class AttackClosestEnemy(object):
    def act(self, obs, our_play_id, enemy_play_id):
        our_agents = obs.units[our_play_id]
        actions = []
        for i in range(len(our_agents)):
            action = self.act_one_action(i, obs, our_play_id, enemy_play_id)
            actions.append(action)
        return actions

    def act_one_action(self, i, obs, our_play_id, enemy_play_id):
        agent = obs.units[our_play_id][i]
        enemy_agents = obs.units[enemy_play_id]
        myagent_id = agent.id
        min_dis = math.inf
        atk_enemy_id = None
        for e in enemy_agents:
            d = (agent.x - e.x) ** 2 + (agent.y - e.y) ** 2
            if min_dis > d:
                min_dis = d
                atk_enemy_id = e.id
        return [myagent_id, atk_enemy_id]


class AttackWeakestNearestEnemy(object):
    def act(self, obs, our_play_id, enemy_play_id):
        our_agents = obs.units[our_play_id]
        actions = []
        for i in range(len(our_agents)):
            action = self.act_one_action(i, obs, our_play_id, enemy_play_id)
            actions.append(action)
        return actions

    def act_one_action(self, i, obs, our_play_id, enemy_play_id):
        agent = obs.units[our_play_id][i]
        enemy_agents = obs.units[enemy_play_id]
        myagent_id = agent.id
        atk_enemy_id = None
        hps = []
        for e in enemy_agents:
            hps.append(e.health + e.shield)
        idxs = np.argsort(hps)
        min_hp = hps[idxs[0]]
        min_dis = math.inf
        for idx in idxs:
            d = (agent.x - enemy_agents[idx].x) ** 2 + (agent.y - enemy_agents[idx].y) ** 2
            e_hp = enemy_agents[idx].health + enemy_agents[idx].shield
            if min_dis > d and e_hp <= min_hp:
                min_dis = d
                atk_enemy_id = enemy_agents[idx].id
            elif e_hp > min_hp:
                break
        return [myagent_id, atk_enemy_id]
