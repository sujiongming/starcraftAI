from rule_based_demo.starcraft_rule_env import StarCraftRuleBasedEnv
from rule_based_demo.rule_based_agents import AttackRandomEnemy, AttackClosestEnemy, AttackWeakestNearestEnemy
import sys

if __name__ == '__main__':

    agent = None
    agent_type = 'closest'  # random,closest,weakest_nearest

    if agent_type == 'random':
        agent = AttackRandomEnemy()
    elif agent_type == 'closest':
        agent = AttackClosestEnemy()
    elif agent_type == 'weakest_nearest':
        agent = AttackWeakestNearestEnemy()

    if agent is None:
        print('error: you should select a agent AI type in [random, closest, weakest_nearest]..')
        sys.exit()

    env = StarCraftRuleBasedEnv()

    episodes = 0
    win = 0
    while episodes < 20:
        obs = env.reset()
        done = False
        while not done:
            our_play_id = env.state1.player_id
            enemy_play_id = env.state2.player_id
            actions = agent.act(obs, our_play_id, enemy_play_id)
            obs, reward, done, info = env.step(actions)

        win += env.stat['success']
        episodes += 1
        state1 = info['state1']
        state2 = info['state2']
    print('run episodes:', episodes, ", win rate: ", round(win / episodes, 3), ", ours alive:",
          len(state1.units[state1.player_id]), ", enemies alive:", len(state2.units[state2.player_id]))

    env.close()
