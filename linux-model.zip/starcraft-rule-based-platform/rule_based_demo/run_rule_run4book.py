from rule_based_demo.starcraft_rule_env4book import StarCraftRuleBasedEnv
from rule_based_demo.rule_based_agents import AttackRandomEnemy, AttackClosestEnemy, AttackWeakestNearestEnemy
import sys


def run4Book(agent_type, frame_skip, nagents, nenemies, run_num=200, init_our_formation='O', init_enemy_formation='O', enemyAI_type='builtin', set_gui=0,speed=0):
    agent = None
    # agent_type = 'closest'  # random,closest,weakest_nearest
    if agent_type == 'random':
        agent = AttackRandomEnemy()
    elif agent_type == 'closest':
        agent = AttackClosestEnemy()
    elif agent_type == 'weakest_nearest':
        agent = AttackWeakestNearestEnemy()
    if agent is None:
        print('error: you should select a agent AI type in [random, closest, weakest_nearest]..')
        sys.exit()
    env = StarCraftRuleBasedEnv(frame_skip, nagents, nenemies, init_our_formation=init_our_formation, init_enemy_formation=init_enemy_formation,
                                enemyAI_type=enemyAI_type, set_gui=set_gui, speed=speed)
    episodes = 0
    win = 0
    while episodes < run_num:
        obs = env.reset()
        done = False
        while not done:
            our_play_id = env.state1.player_id
            enemy_play_id = env.state2.player_id
            actions = agent.act(obs, our_play_id, enemy_play_id)
            obs, reward, done, info = env.step(actions)

        win += env.stat['success']
        episodes += 1

    print('agent_type,frame_skip,nagents,nenemies,init_our_formation,init_enemy_formation,enemyAI_type:', agent_type, frame_skip, nagents, nenemies,
          init_our_formation, init_enemy_formation, enemyAI_type, '==> run episodes:', episodes, ", win rate: ",
          round(win / episodes, 3), )
    env.close()