'''
basic demo env
developed by sjm
2019-01-10
'''
import gym
import torchcraft.Constants as tcc
import torchcraft as tc
import random
import yaml
import subprocess
import sys
import os
import atexit
import uuid
import tempfile
from rule_based_demo.rule_based_agents import AttackRandomEnemy, AttackClosestEnemy, AttackWeakestNearestEnemy

DISTANCE_FACTOR = 8


class StarCraftRuleBasedEnv(gym.Env):

    def __init__(self):

        self.config_path = '/home/star/201812-class/starcraft-rule-based-platform/rule_based_demo/config.yml'
        self.torchcraft_dir = '/home/star/Public/TorchCraft'
        options = self.load_config_options()
        self.start_torchcraft(options)

        self.server_ip = '127.0.0.1'
        self.frame_skip = 1
        self.speed = 0
        self.set_gui = 1  # 1 0
        self.max_episode_steps = 600

        self.first_reset = True
        self.obs = None
        self.state1 = None  # for our agents
        self.state2 = None  # for enemy agents
        self.episode_steps = 0
        self.builtin_flag = True  # builtin AI Flag, attack_move once, no need to modified
        self.enemyAI_type = 'builtin'  # builtin,closest,weakest_nearest,random
        self.stat = {}

        self.our_unit_type = 0
        self.enemy_unit_type = 0
        self.nagents = 20   # 5 10 20
        self.nenemies = 20  # 5 10 20
        self.init_range_start = 100
        self.init_range_end = 150
        self.init_our_formation = 'O'  # I,O,C,R
        self.init_enemy_formation = 'O'  # I:like I,O:together,C:Semicircle,R:random
        self._set_units()

    def _set_units(self):
        # First element is our unit's id, 1 is quantity,
        # -1, -1, init_range_start, init_range_end
        # say that randomly initialize x and y coordinates
        # within init_range_start and init_range_end

        if self.init_our_formation == 'R':
            self.my_unit_pairs = [(self.our_unit_type, 1, -1, -1,
                                   self.init_range_start, self.init_range_end)
                                  for _ in range(self.nagents)]

        elif self.init_our_formation == 'O':
            # 0 for marine, 37 for zergling, 2 for vulture, 65 for zealot
            self.my_unit_pairs = [(self.our_unit_type, self.nagents, 100 * DISTANCE_FACTOR, 125 * DISTANCE_FACTOR,
                                   self.init_range_start, self.init_range_end)]
        elif self.init_our_formation == 'I':

            self.my_unit_pairs = []
            for i in range(self.nagents):
                if i < self.nagents / 2 and self.nagents % 2 == 1:
                    self.my_unit_pairs.append((self.our_unit_type, 1, 100 * DISTANCE_FACTOR, (125 - 4 * i) * DISTANCE_FACTOR,
                                               self.init_range_start, self.init_range_end))
                elif i > self.nagents / 2 and self.nagents % 2 == 1:
                    self.my_unit_pairs.append((self.our_unit_type, 1, 100 * DISTANCE_FACTOR, (125 + 4 * (i - self.nagents // 2)) * DISTANCE_FACTOR,
                                               self.init_range_start, self.init_range_end))

                if i <= self.nagents / 2 and self.nagents % 2 == 0:
                    self.my_unit_pairs.append((self.our_unit_type, 1, 100 * DISTANCE_FACTOR, (125 + 2 - 4 * i) * DISTANCE_FACTOR,
                                               self.init_range_start, self.init_range_end))
                elif i > self.nagents / 2 and self.nagents % 2 == 0:
                    self.my_unit_pairs.append((self.our_unit_type, 1, 100 * DISTANCE_FACTOR, (125 + 2 + 4 * (i - self.nagents // 2)) * DISTANCE_FACTOR,
                                               self.init_range_start, self.init_range_end))

        # design enemy init formation
        if self.init_enemy_formation == 'R':
            self.enemy_unit_pairs = [(self.enemy_unit_type, 1, -1, -1,
                                      self.init_range_start, self.init_range_end)
                                     for _ in range(self.nenemies)]
        elif self.init_enemy_formation == 'O':
            self.enemy_unit_pairs = [(self.enemy_unit_type, self.nenemies, 150 * DISTANCE_FACTOR, 125 * DISTANCE_FACTOR,
                                      self.init_range_start, self.init_range_end)]

        elif self.init_enemy_formation == 'I':

            self.enemy_unit_pairs = []
            for i in range(self.nenemies):
                if i < self.nenemies / 2 and self.nenemies % 2 == 1:
                    self.enemy_unit_pairs.append((self.our_unit_type, 1, 150 * DISTANCE_FACTOR, (125 - 4 * i) * DISTANCE_FACTOR,
                                                  self.init_range_start, self.init_range_end))
                elif i > self.nenemies / 2 and self.nenemies % 2 == 1:
                    self.enemy_unit_pairs.append((self.our_unit_type, 1, 150 * DISTANCE_FACTOR, (125 + 4 * (i - self.nagents // 2)) * DISTANCE_FACTOR,
                                                  self.init_range_start, self.init_range_end))

                if i <= self.nenemies / 2 and self.nenemies % 2 == 0:
                    self.enemy_unit_pairs.append((self.our_unit_type, 1, 150 * DISTANCE_FACTOR, (125 + 2 - 4 * i) * DISTANCE_FACTOR,
                                                  self.init_range_start, self.init_range_end))
                elif i > self.nenemies / 2 and self.nenemies % 2 == 0:
                    self.enemy_unit_pairs.append((self.our_unit_type, 1, 150 * DISTANCE_FACTOR, (125 + 2 + 4 * (i - self.nagents // 2)) * DISTANCE_FACTOR,
                                                  self.init_range_start, self.init_range_end))

    def _action_space(self):
        return None

    def _observation_space(self):

        return None

    def _make_commands(self, actions):
        cmds = []
        for action in actions:
            cmds.append([
                tcc.command_unit_protected,
                action[0],
                tcc.unitcommandtypes.Attack_Unit,
                action[1],
            ])
            cmds.append([tcc.draw_unit_line, action[0], action[1], 111])  # 111 red

        return cmds

    def _make_observation(self):

        return NotImplementedError

    def _has_step_completed(self):
        return True

    def step(self, action):

        self.episode_steps += 1

        cmds = self._make_commands(action)
        self.client1.send(cmds)
        self.state1 = self.client1.recv()

        enemy_cmds = self._get_enemy_commands()
        self.client2.send(enemy_cmds)
        # self.client2.send([])
        self.state2 = self.client2.recv()

        reward = self._compute_reward()
        done = self._check_done()
        info = self._get_info()
        self.obs = self.state1
        self._update_stat()
        return self.obs, reward, done, info

    def _compute_reward(self):
        reward = 0.
        if self._check_done():
            if self._has_won():
                reward = 1
            else:
                reward = 0

        return reward

    def _check_done(self):
        """Returns true if the episode was ended"""
        # If either of my units or enemy units has a count of 0 or if
        # we have reached max steps then we are finished
        return (len(self.state1.units[self.state1.player_id]) == 0 or \
                len(self.state2.units[self.state2.player_id]) == 0 or \
                self.episode_steps == self.max_episode_steps)

    def _get_info(self):
        """Returns a dictionary contains debug info"""
        return {
            'state1': self.state1,
            'state2': self.state2
        }

    def _update_stat(self):
        if self._check_done():
            if self._has_won():
                self.stat['success'] = 1
            else:
                self.stat['success'] = 0

            self.stat['steps_taken'] = self.episode_steps

        return self.stat

    def _has_won(self):
        # Our units should be more than 0 and enemy units should be 0
        return (
                len(self.state1.units[self.state1.player_id]) > 0 and \
                len(self.state2.units[self.state2.player_id]) == 0
        )

    def reset(self):

        self.episode_steps = 0

        if self.first_reset:
            self.init_conn()
            self.first_reset = False

        self.try_killing()

        c1 = []
        c2 = []

        for unit_pair in self.my_unit_pairs:
            c1 += self._get_create_units_command(self.state1.player_id, unit_pair)

        for unit_pair in self.enemy_unit_pairs:
            c2 += self._get_create_units_command(self.state2.player_id, unit_pair)

        self.client1.send(c1)
        self.client2.send(c2)
        self.state1 = self.client1.recv()
        self.state2 = self.client2.recv()

        while len(self.state1.units.get(self.state1.player_id, [])) == 0 \
                and len(self.state2.units.get(self.state2.player_id, [])) == 0:
            self._empty_step()

        self.stat = {}
        self.builtin_flag = True
        self.obs = self.state1
        return self.obs

    def _empty_step(self):
        """Make an empty step where we don't send anything to server"""
        self.client1.send([])
        self.state1 = self.client1.recv()
        self.client2.send([])
        self.state2 = self.client2.recv()

    def _get_create_units_command(self, player_id, unit_pair):
        """Generates command for creating units"""

        defaults = [1, 100, 100, 0, self.state1.map_size[0] - 10][len(unit_pair) - 1:]
        unit_type, quantity, x, y, start, end = (list(unit_pair) + defaults)[:6]

        return self.create_units(player_id, quantity, x=x, y=y,
                                 unit_type=unit_type, start=start,
                                 end=end)

    def create_units(self, player_id, quantity, unit_type=0, x=100, y=100, start=0, end=250):
        """Create units in specific location (x, y) within bounding box of
        (start, start) and (end, end). If either of x or y is -1, that coordindate is
        initialized randomly within the range specified.

        Arguments:
            player_id {int} -- ID of the player for which to create units
            quantity {int} -- Number of units to create

        Keyword Arguments:
            unit_type {int} -- ID of unit type to create, 0 is marine (default: {0})
            x {int} -- X coordinate of initialization. If -1, it is random (default: {100})
            y {int} -- Y coordinate of initialization. If -1, it is random (default: {100})
            start {int} -- Start of bounding box (default: {0})
            end {int} -- End of bounding box. (default: {250})

        Default arguments of start and end cover whole map. If you see some errors regarding
        division with zero when you default "end" of 250, try decreasing it.
        """

        # NOTE: If you want some custom kind of initialization, override this function and
        # call parent's create_units in that function
        if x < 0:
            x = (random.randint(0, (end - start)) + start) * DISTANCE_FACTOR

        if y < 0:
            y = (random.randint(0, (end - start)) + start) * DISTANCE_FACTOR
        commands = []

        for _ in range(quantity):
            command = [
                tcc.command_openbw,
                tcc.openbwcommandtypes.SpawnUnit,
                player_id,
                unit_type,
                x,
                y,
            ]
            commands.append(command)
        # print(commands)
        return commands

    def load_config_options(self):
        """Load config options from config file and environment"""
        config = None
        with open(self.config_path, 'r') as f:
            try:
                config = yaml.load(f)
            except yaml.YAMLError as err:
                print('Config yaml error', err)
                sys.exit(0)

        self.bwapi_launcher_path = config['options']['BWAPI_INSTALL_PREFIX']

        # Check if environment contains BWAPI_INSTALL path
        if 'BWAPI_INSTALL_PREFIX' in os.environ:
            self.bwapi_launcher_path = os.environ['BWAPI_INSTALL_PREFIX']

        self.bwapi_launcher_path = os.path.join(self.bwapi_launcher_path,
                                                'bin', 'BWAPILauncher')

        # Set environment variables to be passed directly to BWAPI
        tmpfile = os.path.join(tempfile.gettempdir(), str(uuid.uuid4()))
        options = dict(os.environ)
        for key, val in config['options'].items():
            options[key] = str(val)

        options['BWAPI_CONFIG_AUTO_MENU__GAME_TYPE'] = "USE MAP SETTINGS"
        options['BWAPI_CONFIG_AUTO_MENU__AUTO_RESTART'] = "ON"
        # Use LAN and Local mode to start a self-play kind of mode
        options['BWAPI_CONFIG_AUTO_MENU__AUTO_MENU'] = "LAN"
        options['OPENBW_LAN_MODE'] = "LOCAL"
        options['OPENBW_LOCAL_PATH'] = tmpfile
        options['BWAPI_CONFIG_AUTO_MENU__MAP'] = os.path.abspath(options['BWAPI_CONFIG_AUTO_MENU__MAP'])

        return options

    def start_torchcraft(self, options):
        """Starts torchcraft on available port and given IP with passed options"""
        cmds = []
        cmds.append(os.path.expanduser(self.bwapi_launcher_path))

        proc1 = subprocess.Popen(cmds,
                                 cwd=os.path.expanduser(self.torchcraft_dir),
                                 env=options,
                                 stdout=subprocess.PIPE
                                 )
        self._register_kill_at_exit(proc1)

        proc2 = subprocess.Popen(cmds,
                                 cwd=os.path.expanduser(self.torchcraft_dir),
                                 env=options,
                                 stdout=subprocess.PIPE
                                 )
        self._register_kill_at_exit(proc2)

        matchstr = b"TorchCraft server listening on port "
        for line in iter(proc1.stdout.readline, ''):
            if len(line) != 0:
                print(line.rstrip().decode('utf-8'))
            if line[:len(matchstr)] == matchstr:
                self.server_port1 = int(line[len(matchstr):].strip())
                break

        for line in iter(proc2.stdout.readline, ''):
            if len(line) != 0:
                print(line.rstrip().decode('utf-8'))
            if line[:len(matchstr)] == matchstr:
                self.server_port2 = int(line[len(matchstr):].strip())
                break

    def init_conn(self):
        """Init connection with torchcraft server"""
        # Import torchcraft in this function so that torchcraft is not an explicit
        # dependency for projects importing this repo

        self.client1 = tc.Client()
        self.client1.connect(self.server_ip, self.server_port1)
        self.state1 = self.client1.init()

        self.client2 = tc.Client()
        self.client2.connect(self.server_ip, self.server_port2)
        self.state2 = self.client2.init()

        setup = [[tcc.set_combine_frames, 1],
                 [tcc.set_speed, self.speed],
                 [tcc.set_gui, self.set_gui],
                 [tcc.set_frameskip, self.frame_skip],
                 [tcc.set_cmd_optim, 1]]

        self.client1.send(setup)
        self.state1 = self.client1.recv()
        self.client2.send(setup)
        self.state2 = self.client2.recv()

    def _register_kill_at_exit(self, proc):
        atexit.register(proc.kill)

    def try_killing(self):
        """Keeps sending commands to server for killing units
        until they don't wipe off the map"""

        while len(self.state1.units[self.state1.player_id]) != 0 \
                or len(self.state2.units[self.state2.player_id]) != 0:
            c1units = self.state1.units[self.state1.player_id]
            c2units = self.state2.units[self.state2.player_id]

            self.client1.send(self.kill_units(c1units))
            self.state1 = self.client1.recv()

            self.client2.send(self.kill_units(c2units))
            self.state2 = self.client2.recv()

            for _ in range(10):
                self._empty_step()

    def kill_units(self, units):
        """Tries to kill argument units by passing commands to BWAPI
        [units] is a list of units to be killed.
        """
        commands = []

        for u in units:
            command = [
                tcc.command_openbw,
                tcc.openbwcommandtypes.KillUnit,
                u.id
            ]
            commands.append(command)
        return commands

    def _get_enemy_commands(self):
        cmds = []
        if self.enemyAI_type == 'builtin':
            for unit in self.state2.units[self.state2.player_id]:
                if self.builtin_flag:
                    cmds.append([
                        tcc.command_unit_protected, unit.id,
                        tcc.unitcommandtypes.Attack_Move, -1, 100, 125
                    ])
                cmds.append([tcc.draw_unit_pos_line, unit.id, 100 * DISTANCE_FACTOR, 125 * DISTANCE_FACTOR, 165])
            self.builtin_flag = False
        elif self.enemyAI_type in ['random', 'closest', 'weakest_nearest']:
            agent = None
            if self.enemyAI_type == 'random':
                agent = AttackRandomEnemy()
            elif self.enemyAI_type == 'closest':
                agent = AttackClosestEnemy()
            elif self.enemyAI_type == 'weakest_nearest':
                agent = AttackWeakestNearestEnemy()
            if agent is None:
                print('error: you should select a enemy AI type in [builtin, random, closest, weakest_nearest]...')
                sys.exit()
            our_play_id = self.state2.player_id
            enemy_play_id = self.state1.player_id
            obs = self.state2
            actions = agent.act(obs, our_play_id, enemy_play_id)
            for action in actions:
                cmds.append([
                    tcc.command_unit_protected,
                    action[0],
                    tcc.unitcommandtypes.Attack_Unit,
                    action[1],
                ])
                cmds.append([tcc.draw_unit_line, action[0], action[1], 165])  # 165 blue

        return cmds
