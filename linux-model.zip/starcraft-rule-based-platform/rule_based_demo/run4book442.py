from rule_based_demo.run_rule_run4book import run4Book

if __name__ == '__main__':
    # agent_type = 'closest'  # random,closest,weakest_nearest
    frame_skip = 3
    run4Book('closest', frame_skip=frame_skip, nagents=5, nenemies=5, init_our_formation='I', init_enemy_formation='I')
    run4Book('closest', frame_skip=frame_skip, nagents=5, nenemies=5, init_our_formation='I', init_enemy_formation='O')
    run4Book('closest', frame_skip=frame_skip, nagents=5, nenemies=5, init_our_formation='O', init_enemy_formation='I')
    run4Book('closest', frame_skip=frame_skip, nagents=5, nenemies=5, init_our_formation='O', init_enemy_formation='O')

    run4Book('weakest_nearest', frame_skip=frame_skip, nagents=5, nenemies=5, init_our_formation='I', init_enemy_formation='I')
    run4Book('weakest_nearest', frame_skip=frame_skip, nagents=5, nenemies=5, init_our_formation='I', init_enemy_formation='O')
    run4Book('weakest_nearest', frame_skip=frame_skip, nagents=5, nenemies=5, init_our_formation='O', init_enemy_formation='I')
    run4Book('weakest_nearest', frame_skip=frame_skip, nagents=5, nenemies=5, init_our_formation='O', init_enemy_formation='O')
