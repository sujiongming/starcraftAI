from rule_based_demo.run_rule_run4book import run4Book

if __name__ == '__main__':
    # agent_type = 'closest'  # random,closest,weakest_nearest

    run4Book('weakest_nearest', frame_skip=1, nagents=5, nenemies=5)
    run4Book('weakest_nearest', frame_skip=3, nagents=5, nenemies=5)
    run4Book('weakest_nearest', frame_skip=5, nagents=5, nenemies=5)
    run4Book('weakest_nearest', frame_skip=7, nagents=5, nenemies=5)
    run4Book('weakest_nearest', frame_skip=9, nagents=5, nenemies=5)
    run4Book('weakest_nearest', frame_skip=11, nagents=5, nenemies=5)
    run4Book('weakest_nearest', frame_skip=13, nagents=5, nenemies=5)

    run4Book('weakest_nearest', frame_skip=1, nagents=10, nenemies=10)
    run4Book('weakest_nearest', frame_skip=3, nagents=10, nenemies=10)
    run4Book('weakest_nearest', frame_skip=5, nagents=10, nenemies=10)
    run4Book('weakest_nearest', frame_skip=7, nagents=10, nenemies=10)
    run4Book('weakest_nearest', frame_skip=9, nagents=10, nenemies=10)
    run4Book('weakest_nearest', frame_skip=11, nagents=10, nenemies=10)
    run4Book('weakest_nearest', frame_skip=13, nagents=10, nenemies=10)

    run4Book('weakest_nearest', frame_skip=1, nagents=20, nenemies=20)
    run4Book('weakest_nearest', frame_skip=3, nagents=20, nenemies=20)
    run4Book('weakest_nearest', frame_skip=5, nagents=20, nenemies=20)
    run4Book('weakest_nearest', frame_skip=7, nagents=20, nenemies=20)
    run4Book('weakest_nearest', frame_skip=9, nagents=20, nenemies=20)
    run4Book('weakest_nearest', frame_skip=11, nagents=20, nenemies=20)
    run4Book('weakest_nearest', frame_skip=13, nagents=20, nenemies=20)