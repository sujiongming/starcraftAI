from rule_based_demo.run_rule_run4book import run4Book

if __name__ == '__main__':
    run4Book('closest', frame_skip=1, nagents=5, nenemies=5, init_our_formation='I', init_enemy_formation='O', set_gui=1, speed=10000)
    # run4Book('closest', frame_skip=3, nagents=5, nenemies=5)
