for i in range(5, 30, 5):
    print(i)

info = {'alive_mask': 1}
info.update({
    'state1': 22,
    'state2': 33
}
)
print(info)
dd = 111
a = 222
