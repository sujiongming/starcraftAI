Starcraft AI Platform 1.0

create by sjm
tel&weixin:15173115272
email:sujiongming07@nudt.edu.cn
time:201812
Features:
-support starcraft bot vs bot
-built in AI, attack closest, and attack weakest
-openAI Gym API
-run with ubuntu 16.04 X64, python3.5



1.install

sudo apt-get update
sudo apt-get install libsdl2-dev
pip install pyyaml
pip install numpy
pip install gym

mkdir ~/Public
cd ~/Public
git clone https://github.com/TorchCraft/TorchCraft
cd TorchCraft && git submodule update --init --recursive
Now we will install zstd
git clone https://github.com/facebook/zstd.git
cd zstd && sudo make install
sudo ldconfig
sudo apt-get install libczmq-dev. Use sudo if needed.
sudo apt-get install libsdl2-2.0 cmake
cd ~/Public
git clone https://github.com/openbw/openbw
git clone https://github.com/openbw/bwapi
cd bwapi && mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release -DOPENBW_DIR=../../openbw -DOPENBW_ENABLE_UI=1 -DCMAKE_INSTALL_PREFIX=~/Public/bwapi
make install
cd ~/Public/TorchCraft/BWEnv; mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=relwithdebinfo -DBWAPI_DIR=../../bwapi/ && make -j

install torchcraft 1.4
cd ~/Public/TorchCraft
pip install -e.

copy BrooDat.mpq, StarDat.mpq, Patch_rt.mpq to TorchCraft

2.run
config incude config.yml and flags.py
python attack_closest.py --server_ip 127.0.0.1 --set_gui --max_steps 200 --init_range_start 100 --init_range_end 150 --full_vision --unlimited_attack_range --initialize_together --initialize_enemy_together

3.some rule-based AI results for 500games
 M5vM5 enemy ATK_CLOSEST  ATK_WEAKEST BUILTIN
 ourAI
ATK_CLOSEST   0.54         0.25         0.76
ATK_WEAKEST   0.71         0.50         0.84


4.design our AI
use the gym develop model

single agent:
-x,y
-health
-shield
-sight range
-fire range
-cool duration:CD
-type:can attack ground and/or air
-attack kill power

multi-agent:
-attack shape
-attack order
-...