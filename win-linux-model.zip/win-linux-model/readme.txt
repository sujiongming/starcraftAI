this project is for python3.5, tensorflow, gym, torch, torchcraft.

1. install gym 0.10.5
pip install --upgrade pip
conda create -n py35d python=3.5
source activate py35d
pip install gym

2. install torchcraft1.3
cd py
pip install -e .

3. pip install tensorflow==1.8
4. conda install tqdm



