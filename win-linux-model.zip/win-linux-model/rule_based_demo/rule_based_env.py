import gym

import torchcraft.Constants as tcc
import torchcraft as tc


class RuleBasedEnv(gym.Env):
    def __init__(self, server_ip, server_port, speed, frame_skip,
                 max_episode_steps=800):
        self.ip = server_ip
        self.port = server_port
        self.client = tc.Client()
        self.client.connect(server_ip, server_port)
        self.state = self.client.init(micro_battles=True)
        self.speed = speed
        self.frame_skip = frame_skip
        self.max_episode_steps = max_episode_steps

        self.episode_steps = 0
        self.state = None

        setup = [
            [tcc.set_speed, self.speed],
            [tcc.set_gui, 1],
            [tcc.set_frameskip, self.frame_skip],
            [tcc.set_cmd_optim, 1]
        ]
        self.client.send(setup)

    def __del__(self):
        self.client.close()

    def step(self, actions):
        self.episode_steps += 1

        self.client.send(self._make_commands(actions))
        # self.client.receive()
        self.state = self.client.recv()
        reward = 0.
        done = False
        if (self.episode_steps == self.max_episode_steps) or len(self.state.units[0]) == 0 or len(
                self.state.units[1]) == 0:
            done = True
        info = self._get_info()

        return self.state, reward, done, info

    def reset(self):
        self.state = self.client.recv()
        while bool(self.state.waiting_for_restart):
            self.client.send([])
            self.state = self.client.recv()

        self.state = self.client.recv()
        self.episode_steps = 0
        return self.state

    def reset_data(self):
        """Reset the state data"""
        pass

    def _action_space(self):
        """Returns a space object"""
        raise NotImplementedError

    def _observation_space(self):
        """Returns a space object"""
        raise NotImplementedError

    def _make_commands(self, actions):
        """Returns a game command list based on the action"""
        cmd = []
        for action in actions:
            cmd.append([
                tcc.command_unit_protected,
                action[0],
                tcc.unitcommandtypes.Attack_Unit,
                action[1],
            ])


        return cmd

    def _make_observation(self):
        """Returns a observation object based on the game state"""
        raise NotImplementedError

    def _compute_reward(self):
        """Returns a computed scalar value based on the game state"""
        raise NotImplementedError

    def _check_done(self):
        """Returns true if the episode was ended"""
        return bool(self.state.game_ended) or self.state.battle_just_ended

    def _get_info(self):
        """Returns a dictionary contains debug info"""

        return {}

    def render(self, mode='human', close=False):
        pass
