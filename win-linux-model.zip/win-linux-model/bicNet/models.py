# https://github.com/openai/baselines/baselines/ddpg/models.py

import tensorflow as tf
import tensorflow.contrib as tc
from tensorflow.contrib import rnn
import numpy as np


class Model(object):
    def __init__(self, name):
        self.name = name

    @property
    def vars(self):
        vars = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope=self.name)
        vars_without_optimizer = [var for var in vars if 'optimizer' not in var.name]
        return vars_without_optimizer

    @property
    def trainable_vars(self):
        return tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope=self.name)

    @property
    def perturbable_vars(self):
        return [var for var in self.trainable_vars if 'LayerNorm' not in var.name]


class Dynamic_Actor(Model):
    def __init__(self, nb_unit_actions, name='actor', layer_norm=True, time_step=5):
        super(Dynamic_Actor, self).__init__(name=name)
        self.nb_unit_actions = nb_unit_actions
        self.layer_norm = layer_norm
        self.time_step = time_step

    # au alive units.
    def __call__(self, ud, mask, au, n_hidden=64, reuse=False):
        with tf.variable_scope(self.name) as scope:
            if reuse:
                scope.reuse_variables()
            # x [ batch_size, time_step, obs_dim]
            x = ud
            if self.layer_norm:
                x = tc.layers.layer_norm(x, center=True, scale=True)

            x = tf.layers.dense(x, 64)
            if self.layer_norm:
                x = tc.layers.layer_norm(x, center=True, scale=True)
            x = tf.nn.relu(x)
            shape = x.get_shape().as_list()
            x = tf.reshape(x, [-1, self.time_step, shape[-1]])
            # build bidirection lstm
            lstm_fw_cell = rnn.BasicLSTMCell(n_hidden, forget_bias=1.0)
            lstm_bw_cell = rnn.BasicLSTMCell(n_hidden, forget_bias=1.0)
            x, _ = tf.nn.bidirectional_dynamic_rnn(lstm_fw_cell, lstm_bw_cell, x,
                                                   dtype=tf.float32,
                                                   sequence_length=au)
            x = tf.concat(x, 2)
            if self.layer_norm:
                x = tc.layers.layer_norm(x, center=True, scale=True)
            x = tf.nn.relu(x)
            x = tf.reshape(x, [-1, self.time_step * n_hidden * 2, 1])
            x = tf.layers.conv1d(x, self.nb_unit_actions, kernel_size=n_hidden * 2, strides=n_hidden * 2,
                                 kernel_initializer=tf.random_uniform_initializer(minval=-3e-3, maxval=3e-3))
            x = tf.nn.tanh(x)
        return x


class Dynamic_Critic(Model):
    def __init__(self, name='critic', layer_norm=True, time_step=5):
        super(Dynamic_Critic, self).__init__(name=name)
        self.layer_norm = layer_norm
        self.time_step = time_step

    def __call__(self, ud, action, mask, au, n_hidden=64, reuse=False, unit_data=False):
        with tf.variable_scope(self.name) as scope:
            if reuse:
                scope.reuse_variables()
            # x [ batch_size, time_step, obs_dim]
            x = ud
            if self.layer_norm:
                x = tc.layers.layer_norm(x, center=True, scale=True)
            x = tf.layers.dense(x, 64)
            if self.layer_norm:
                x = tc.layers.layer_norm(x, center=True, scale=True)
            x = tf.nn.relu(x)
            # format action to be [ batch_size*time_step, nb_actions]
            x = tf.concat([x, action], axis=-1)
            x = tf.layers.dense(x, 64)
            if self.layer_norm:
                x = tc.layers.layer_norm(x, center=True, scale=True)
            x = tf.nn.relu(x)
            shape = x.get_shape().as_list()
            x = tf.reshape(x, [-1, self.time_step, shape[-1]])

            lstm_fw_cell = rnn.BasicLSTMCell(n_hidden, forget_bias=1.0)
            lstm_bw_cell = rnn.BasicLSTMCell(n_hidden, forget_bias=1.0)
            x, _ = tf.nn.bidirectional_dynamic_rnn(lstm_fw_cell, lstm_bw_cell, x,
                                                   dtype=tf.float32,
                                                   sequence_length=au)
            x = tf.concat(x, 2)
            if self.layer_norm:
                x = tc.layers.layer_norm(x, center=True, scale=True)
            x = tf.nn.relu(x)
            x = tf.reshape(x, [-1, self.time_step * n_hidden * 2, 1])
            q = tf.layers.conv1d(x, 1, kernel_size=n_hidden * 2, strides=n_hidden * 2,
                                 kernel_initializer=tf.random_uniform_initializer(minval=-3e-3, maxval=3e-3))
            q = tf.squeeze(q, [-1])
            Q = tf.reduce_sum(q, axis=1, keepdims=True)
        if unit_data:
            return Q, q
        return Q

    @property
    def output_vars(self):
        output_vars = [var for var in self.trainable_vars if 'output' in var.name]
        return output_vars
