import math
import numpy as np

def unit_top_k_reward(k, unit, unit_dict_list):
    d_list = []
    flag_list = []
    health_delta_list = []
    for unit_dict in unit_dict_list:
        flag = unit_dict.flag
        for i in unit_dict.id_list:
            t = unit_dict.units_dict[i]
            if t.die and t.delta_health <= 0:
                continue
            d = get_distance(unit.x, unit.y, t.x, t.y)
            health_delta_list.append(t.delta_health * 100. / t.max_health)
            d_list.append(d)
            flag_list.append(flag)
    top_k_idxes = np.argsort(np.array(d_list))[:k]
    top_k_flags = np.array(flag_list)[top_k_idxes]
    # enemy flag 1, myself flag 0
    num_enemy = np.sum(top_k_flags) + 0.
    num_myself = len(top_k_idxes) - num_enemy + 0.
    top_k_delta = np.array(health_delta_list)[top_k_idxes]
    myself_delta_norm = 0
    enemy_delta_norm = 0
    if num_myself > 0:
        myself_delta_norm = np.sum(np.multiply(top_k_delta, 1 - top_k_flags)) / num_myself
    if num_enemy > 0:
        enemy_delta_norm = np.sum(np.multiply(top_k_delta, top_k_flags)) / num_enemy
    unit_reward = enemy_delta_norm - myself_delta_norm
    return unit_reward


def get_degree(x1, y1, x2, y2):
    radians = math.atan2(y2 - y1, x2 - x1)
    return math.degrees(radians)


def get_distance(x1, y1, x2, y2):
    return math.hypot(x2 - x1, y2 - y1)


def get_distance_degree(unit1, unit2):
    distance = get_distance(unit1.x, unit1.y, unit2.x, unit2.y)
    degree = get_degree(unit1.x, unit1.y, unit2.x, unit2.y) / 180.
    return distance, degree


def get_distance_degree_0807(x, y, unit2):
    distance = get_distance(x, y, unit2.x, unit2.y)
    degree = get_degree(x, y, unit2.x, unit2.y) / 180.
    return distance, degree


def get_position(degree, distance, x1, y1):
    theta = math.pi / 2 - math.radians(degree)
    return x1 + distance * math.sin(theta), y1 + distance * math.cos(theta)


def get_position2(degree, distance, x1, y1):
    theta = math.radians(degree)  # -180-180 not -1->1
    return x1 + distance * math.cos(theta), y1 + distance * math.sin(theta)


def print_progress(episodes, wins):
    print("Episodes: %4d | Wins: %4d | WinRate: %1.3f" % (
        episodes, wins, wins / (episodes + 1E-6)))


map_channels_table = {
    "unit_density": 1,
    "unit_location": 1,
    "unit_data": 0,
    "health": 3,
    "shield": 3,
    "type": 3,
    "flag": 3
}

obs_dtype = {
    'ul': "uint8",
    'ud': "float32",
    's': "uint8",
    'mask': "uint8",
    'au': "int32"
}

obs_cls_table = {
    "unit_location": "ul",
    "unit_density": "s",
    "unit_data": "ud",
    "health": "s",
    "shield": "s",
    "type": "s",
    "flag": "s"
}
