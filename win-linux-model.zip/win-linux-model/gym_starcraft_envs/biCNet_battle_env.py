import numpy as np
from gym import spaces
import torchcraft.Constants as tcc
import gym_starcraft_envs.utils as utils
import gym_starcraft_envs.starcraft_env as sc

# numeber of self-camp numbers
MYSELF_NUM = 5
# number of enemy-camp numbers
ENEMY_NUM = 5

# # numeber of self-camp numbers
# MYSELF_NUM = 15
# # number of enemy-camp numbers
# ENEMY_NUM = 16


# numeber of self-camp numbers
# MYSELF_NUM = 10
# # number of enemy-camp numbers
# ENEMY_NUM = 13

# Marine 7
SIGHT_DISTANCE = 7.

# calculate the unit reward from the closest K units
K = 5
# calc NEAR_K near units features
NEAR_K = 5

# distance each distance action represents
# DISTANCE_FACTOR = 25.
DISTANCE_FACTOR = 16.

DISTANCE_SCALE = 40.

SHARED_STATES_MYSELF_NUM = MYSELF_NUM
SHARED_STATES_ENEMY_NUM = ENEMY_NUM

# the length of each unit's feature
DATA_NUM = 3
# the feature about the each enemy
ENEMY_DATA_NUM = 2

# the scale applied to unit's health
HEALTH_SCALE = 20.
# time scale to unit's CD
TIME_SCALE = 10.

# Used for Dynamic-RNN. All alive units occupy the first several elements.
DYNAMIC = True  # Dynamic means compression

CROP_LT = (60, 120)
CROP_RB = (100, 140)


class data_unit(object):
    def __init__(self, unit, id):
        self.id = id  # unit id
        self.health = unit.health  # health
        self.x = unit.x  # x
        self.y = unit.y  # y
        self.shield = unit.shield  # shield
        self.attackCD = unit.groundCD  # attackCD
        self.type = unit.type  # type
        self.groundATK = unit.groundATK  # Attack power
        self.groundRange = unit.groundRange  # this can be inferred from training
        self.under_attack = unit.under_attack  # Boolean. whether is under attacking.
        self.attacking = unit.attacking  # Boolean. whether is attacking.
        self.moving = unit.moving  # Boolean. whether is moving.
        self.die = False  # Boolean. alive.
        self.max_health = unit.max_health  # max health of this type of unit.
        self.max_shield = unit.max_shield  # max shield of this type of unit.
        self.pixel_size_x = unit.pixel_size_x  # pixel_size of this type of uni
        self.pixel_size_y = unit.pixel_size_y  # pixel_size on this type of uni
        self._delta_health = 0
        self._delta_shield = 0
        self._delta_attackCD = 0

    def update_data(self, unit):
        # other data remain the same
        self._delta_health = self.health - unit.health  # used to calculate the reward
        self._delta_shield = self.shield - unit.shield
        self._delta_attackCD = self.attackCD - unit.groundCD
        self.health = unit.health
        self.x = unit.x
        self.y = unit.y
        self.shield = unit.shield
        self.attackCD = unit.groundCD
        self.under_attack = unit.under_attack
        self.attacking = unit.attacking
        self.moving = unit.moving
        self.die = False

    @property
    def delta_health(self):
        return self._delta_health

    @property
    def delta_shield(self):
        return self._delta_shield

    # mask this unit in multi-agent setting
    def extract_mask(self):
        if self.die:
            return 0.
        return 1.


class data_unit_dict(object):
    def __init__(self, units, flag):
        self.units_dict = {}
        self.id_mapping = {}
        # myself 0. enemy 1.
        self.flag = flag
        for i in range(len(units)):
            unit = units[i]
            self.id_mapping[unit.id] = i
            self.units_dict[i] = data_unit(unit, unit.id)
        self.id_list = sorted(self.units_dict.keys())
        self.alive_num = -1
        self.num = len(self.id_list)

    def update(self, units):
        for id in self.id_list:
            self.units_dict[id].die = True
        self.alive_num = len(units)
        for u in units:
            id = self.id_mapping[u.id]
            unit = self.units_dict[id]
            unit.update_data(u)

        for id in self.id_list:
            if self.units_dict[id].die:
                unit = self.units_dict[id]
                unit._delta_health = unit.health
                unit.health = 0.

    # the the degree and distance from one unit
    def get_distance_degree(self, unit):
        dd = []
        for id in self.id_list:
            t = self.units_dict[id]
            distance = utils.get_distance(unit.x, unit.y, t.x, t.y) / DISTANCE_SCALE
            degree = utils.get_degree(unit.x, unit.y, t.x, t.y) / 180.
            dd += [distance, degree]
        return dd

    def extract_mask(self):
        mask_list = np.zeros(self.num, dtype="uint8")
        i = 0
        for id in self.id_list:
            unit = self.units_dict[id]
            # skip recording the data
            if unit.die and DYNAMIC:
                continue
            mask_list[i] = self.units_dict[id].extract_mask()
            i += 1
        return mask_list

    def compute_closest_position(self, unit, action):
        # unit vector
        degree = action[1] * 180
        distance = (action[2] + 1.0) * DISTANCE_FACTOR
        tx, ty = utils.get_position2(degree, distance, unit.x, unit.y)
        tx = min(max(int(tx), CROP_LT[0]), CROP_RB[0])
        ty = min(max(int(ty), CROP_LT[1]), CROP_RB[1])
        target_id = self.compute_candidate(tx, ty, unit)
        return target_id, tx, ty

    # choose the closest one
    def compute_candidate(self, tx, ty, unit):
        target_id = None
        d = float('inf')
        for id in self.id_list:
            if self.units_dict[id].die:
                continue
            target_unit = self.units_dict[id]
            td = (target_unit.x - tx) ** 2 + (target_unit.y - ty) ** 2
            if td < d and td <= 4*unit.groundRange ** 2:
                target_id = target_unit.id
                d = td
        return target_id

    # compute rewards specific to each unit
    def compute_unit_rewards(self, k, unit_dict_list):
        idx = 0
        rewards = np.zeros(self.num, dtype="float32")
        for id in self.id_list:
            unit = self.units_dict[id]
            if unit.die:
                if not DYNAMIC:
                    idx += 1
                continue

            rewards[idx] = utils.unit_top_k_reward(k, unit, unit_dict_list)
            idx += 1
        return np.array(rewards)

    def compute_unit_states(self, k, unit_dict_list, map_size):
        idx = 0
        mask_list = np.zeros(self.num, dtype="uint8")
        data_list = np.zeros((self.num,
                              (SHARED_STATES_MYSELF_NUM + SHARED_STATES_ENEMY_NUM) * 4 + DATA_NUM + ENEMY_DATA_NUM * 2 * (
                                      k - 1)), dtype="float32")
        shared_states_myself = np.zeros(SHARED_STATES_MYSELF_NUM * 4, dtype="float32")
        shared_states_enemy = np.zeros(SHARED_STATES_ENEMY_NUM * 4, dtype="float32")

        gb_myself_idx = 0
        gb_enemy_idx = 0

        for unit_dict in unit_dict_list:
            flag = unit_dict.flag  # # myself 0. enemy 1.
            for i in unit_dict.id_list:
                t = unit_dict.units_dict[i]
                if t.die:
                    continue

                distance, degree = utils.get_distance_degree_0807(map_size[0] / 2., map_size[1] / 2., t)
                if flag == 0:  # myself flag 0
                    shared_states_myself[gb_myself_idx * 4] = distance / DISTANCE_SCALE
                    shared_states_myself[gb_myself_idx * 4 + 1] = degree
                    shared_states_myself[gb_myself_idx * 4 + 2] = (t.health + t.shield) / (t.max_health + t.max_shield)
                    shared_states_myself[gb_myself_idx * 4 + 3] = t.attackCD / TIME_SCALE
                    gb_myself_idx += 1
                elif flag == 1:  # emeny flag 1
                    shared_states_enemy[gb_enemy_idx * 4] = distance / DISTANCE_SCALE
                    shared_states_enemy[gb_enemy_idx * 4 + 1] = degree
                    shared_states_enemy[gb_enemy_idx * 4 + 2] = (t.health + t.shield) / (t.max_health + t.max_shield)
                    shared_states_enemy[gb_enemy_idx * 4 + 3] = t.attackCD / TIME_SCALE
                    gb_enemy_idx += 1

        for id in self.id_list:
            unit = self.units_dict[id]
            if unit.die:
                if not DYNAMIC:
                    idx += 1
                continue

            data_list[idx, 0:SHARED_STATES_MYSELF_NUM * 4] = shared_states_myself
            data_list[
            idx,
            SHARED_STATES_MYSELF_NUM * 4: SHARED_STATES_MYSELF_NUM * 4 + SHARED_STATES_ENEMY_NUM * 4] = shared_states_enemy
            data_list[idx, SHARED_STATES_MYSELF_NUM * 4 + SHARED_STATES_ENEMY_NUM * 4:], mask_list[
                idx] = self._unit_top_k_states(k, unit, unit_dict_list)
            idx += 1
        return data_list, mask_list

    def _unit_top_k_states(self, k, unit, unit_dict_list):
        if unit.die:
            return [0, 0, 0] + [0, 0] * (k - 1) * 2, 0.

        data = [(unit.health + unit.shield) / (unit.max_health + unit.max_shield), unit.attackCD / TIME_SCALE,
                unit.delta_health / unit.max_health]
        assert (len(data) == DATA_NUM)

        my_distance_list = []
        my_degree_list = []
        enemy_distance_list = []
        enemy_degree_list = []

        for unit_dict in unit_dict_list:
            flag = unit_dict.flag  # # myself 0. enemy 1.
            for i in unit_dict.id_list:
                t = unit_dict.units_dict[i]
                if t.die:
                    continue

                distance, degree = utils.get_distance_degree(unit, t)
                if distance > SIGHT_DISTANCE:
                    continue

                distance = distance / DISTANCE_SCALE
                if flag == 0:
                    my_distance_list.append(distance)
                    my_degree_list.append(degree)
                elif flag == 1:
                    enemy_distance_list.append(distance)
                    enemy_degree_list.append(degree)
        my_top_k_idxes = np.argsort(np.array(my_distance_list))[:k]
        enemy_top_k_idxes = np.argsort(np.array(enemy_distance_list))[:k - 1]
        data_state = [0, 0] * (k - 1) * 2

        for idx in range(1, len(my_top_k_idxes)):
            data_state[idx * 2 - 2] = my_distance_list[my_top_k_idxes[idx]]
            data_state[idx * 2 - 1] = my_degree_list[my_top_k_idxes[idx]]

        for idx in range(0, len(enemy_top_k_idxes)):
            data_state[idx * 2 + 2 * (k - 1)] = enemy_distance_list[enemy_top_k_idxes[idx]]
            data_state[idx * 2 + 2 * (k - 1) + 1] = enemy_degree_list[enemy_top_k_idxes[idx]]
        data += data_state
        return data, 1.


class BiCNetEnv(sc.StarCraftEnv):
    def __init__(self, server_ip, server_port, speed=0, frame_skip=2,
                 self_play=False, max_episode_steps=1000,
                 map_types_table=("unit_data",)):
        self.map_types_table = map_types_table
        self.obs_cls = list(set(utils.obs_cls_table[k] for k in self.map_types_table)) + ["mask", "au"]
        """
        ud - unit data
        au - number of alive units
        mask - [1, 1, 1, 0, 0] 3 alive among 5 units.
        """
        super(BiCNetEnv, self).__init__(server_ip, server_port, speed,
                                        frame_skip, self_play,
                                        max_episode_steps)
        self.myself_health = None
        self.enemy_health = None
        self.delta_myself_health = 0
        self.delta_enemy_health = 0
        self.nb_unit_actions = 3
        self.myself_obs_dict = None
        self.enemy_obs_dict = None

    # multiple actions.
    def _action_space(self):
        # attack or move, move_degree, move_distance
        action_low = [[-1.0, -1.0, -1.0] for _ in range(MYSELF_NUM)]
        action_high = [[1.0, 1.0, 1.0] for _ in range(MYSELF_NUM)]
        return spaces.Box(np.array(action_low), np.array(action_high))

    @property
    def observation_shape(self):
        obs_space = self.observation_space
        d = {k: obs_space[k].shape for k in obs_space.keys()}
        return d

    @property
    def observation_dtype(self):
        obs_space = self.observation_space
        d = {k: utils.obs_dtype[k] for k in obs_space.keys()}
        return d

    @property
    def reward_shape(self):
        return (MYSELF_NUM,)

    def _observation_space(self):
        obs_space = {}
        if "ud" in self.obs_cls:
            unit_data_low = np.zeros((MYSELF_NUM,
                                      (SHARED_STATES_MYSELF_NUM + SHARED_STATES_ENEMY_NUM) * 4 + DATA_NUM + 2 * (
                                              NEAR_K - 1) * ENEMY_DATA_NUM), dtype=np.float32)
            unit_data_low[:, :] = -1.
            unit_data_high = np.array(
                [[100, 1., 100., 100] * (SHARED_STATES_MYSELF_NUM + SHARED_STATES_ENEMY_NUM)
                 + [100, 100, 100] + [100, 1.] * 2 * (NEAR_K - 1)] * MYSELF_NUM, dtype=np.float32)
            unit_obs_space = spaces.Box(np.array(unit_data_low), np.array(unit_data_high))
            obs_space["ud"] = unit_obs_space

        mask_low = np.zeros(MYSELF_NUM, dtype=np.uint8)
        mask_high = np.ones(MYSELF_NUM, dtype=np.uint8)
        mask_obs_space = spaces.Box(np.array(mask_low), np.array(mask_high))
        obs_space["mask"] = mask_obs_space

        au_obs_space = spaces.Box(np.array(0), np.array(MYSELF_NUM))
        obs_space["au"] = au_obs_space

        assert (set(obs_space.keys()) == set(self.obs_cls))
        return obs_space

    def _make_commands(self, action):
        cmds = []
        assert (len(action) == MYSELF_NUM)
        assert (len(action[0]) == self.nb_unit_actions)
        if self.state is None or action is None:
            return cmds
        # ui - unit index
        ui = 0
        for i in range(0, MYSELF_NUM):
            if self.myself_obs_dict.units_dict[i].die:
                continue
            unit = self.myself_obs_dict.units_dict[i]
            if DYNAMIC:
                # DYNAMIC means [a1, a2, a3, NULL, NULL]
                unit_action = action[ui]
                ui += 1
            else:
                # STATIC means [a1, NULL, a2, NULL, a3]
                unit_action = action[i]
                print('DYNAMIC=False')
            cmds += self.take_action(unit_action, unit)

        return cmds

    def take_action(self, action, unit):
        # attack
        cmds = []
        if unit.id is None:
            return cmds
        if action[0] >= 0:
            enemy_id, tx, ty = self.enemy_obs_dict.compute_closest_position(unit, action)
            if enemy_id is None:
                return cmds
            cmds.append([tcc.command_unit_protected, unit.id, tcc.unitcommandtypes.Attack_Unit, enemy_id])
            cmds.append([tcc.draw_unit_line, unit.id, enemy_id, 111])
            cmds.append([tcc.draw_unit_pos_line, unit.id, int(tx) * 8, int(ty) * 8, 255])  # 255 white
        else:
            degree = action[1] * 180
            distance = (action[2] + 1) * DISTANCE_FACTOR  # at most 2*DISTANCE_FACTOR
            x2, y2 = utils.get_position2(degree, distance, unit.x, unit.y)
            x2 = min(max(int(x2), CROP_LT[0]), CROP_RB[0])
            y2 = min(max(int(y2), CROP_LT[1]), CROP_RB[1])
            cmds.append([tcc.command_unit_protected, unit.id, tcc.unitcommandtypes.Move, -1, int(x2), int(y2)])
            cmds.append([tcc.draw_unit_pos_line, unit.id, int(x2) * 8, int(y2) * 8, 165])
        return cmds

    def _make_observation(self):
        if self.state.player_id != 0:
            print('self.state.player_id', self.state.player_id)

        if self.myself_obs_dict is None:
            self.myself_obs_dict = data_unit_dict(self.state.units[0], 0)

        # enemy's flag is one
        if self.enemy_obs_dict is None:
            self.enemy_obs_dict = data_unit_dict(self.state.units[1], 1)

        self.myself_obs_dict.update(self.state.units[0])
        self.enemy_obs_dict.update(self.state.units[1])

        # construct observation dictionary
        obs = {}
        unit_dict_list = [self.myself_obs_dict, self.enemy_obs_dict]
        if "ud" in self.obs_cls:
            obs["ud"], obs["mask"] = self.myself_obs_dict.compute_unit_states(NEAR_K, unit_dict_list,
                                                                              self.state.map_size)

        if DYNAMIC:
            obs["au"] = self.myself_obs_dict.alive_num
        else:
            obs["au"] = MYSELF_NUM

        return obs

    def _compute_reward(self):
        unit_dict_list = [self.myself_obs_dict, self.enemy_obs_dict]
        reward = self.myself_obs_dict.compute_unit_rewards(K, unit_dict_list)
        return reward / HEALTH_SCALE  # -0.02

    def reset_data(self):
        while len(self.state.units) == 0 or len(self.state.units[0]) != MYSELF_NUM or len(
                self.state.units[1]) != ENEMY_NUM:
            self.client.send([])
            self.state = self.client.recv()

        self.myself_obs_dict = None
        self.enemy_obs_dict = None
        self.advanced_termination = True

    def _check_win(self):
        if self.enemy_obs_dict.alive_num > 0:
            return False
        self.episode_wins += 1
        return True

    def check_win(self):
        return self._check_win()

    def _check_done(self):
        if self.myself_obs_dict.alive_num == 0 or self.enemy_obs_dict.alive_num == 0:
            self._check_win()
            return True
        if self.episode_steps >= self.max_episode_steps:
            print("reach the max_episode_steps")
            self._check_win()
            self.advanced_termination = True
            return True
        return False
